# MuseoVivo Backend - Minimal
This is a minimal backend scaffold for MuseoVivo.


## Artwork endpoints

GET /api/artwork/{id} -> returns artwork by id (id is a string like 'obra_01')
POST /api/artwork -> create or update artwork (JSON body)
